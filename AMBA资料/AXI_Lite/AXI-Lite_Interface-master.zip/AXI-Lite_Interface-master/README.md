This is an implementation of the Slave AXI-lite Interface, adapted from the auto-generated filesfrom Xilinx Vivado.

I devised the implementation so that both the custom logic and AXI interface can write the slave registers without araising arousing Multi-drive issues. 

This two files are a simple demo, where the custom logic is a simple adder. 
