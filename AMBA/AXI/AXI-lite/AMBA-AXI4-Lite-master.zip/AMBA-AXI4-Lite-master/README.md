### **WARNING: Not a serious Project**

# AMBA-AXI4-Lite
Master and Slave made using AMBA AXI4 Lite protocol.

# by Somya Dashora
==================

