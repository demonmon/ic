# AXI_Lite
AXI Lite module RTL

Simple AXI Lite module, which gets data from user and sends by AXI-Lite interface
